# Desarrollo en React .JS

<h2>Ecommerce - Trabajo integrador</h2>

Trabajo integrador para la Diplomatura en Programación Fullstack - Universidad Tecnológica Nacional

Work in progress 🤓