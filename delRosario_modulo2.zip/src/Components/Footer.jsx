function Footer(){
    return(
        <h2>Footer</h2>
    )
}

export default Footer