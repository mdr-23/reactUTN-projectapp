import Productos from "../Components/Productos"

function Home(){
    return(
        <>
            <h1>Bienvenidos</h1>
            <Productos />

        </>
    )
}

export default Home